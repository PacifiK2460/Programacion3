/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Usuarios;

/**
 *
 * @author chago
 */
public class UsuariosException extends Exception {

    public UsuariosException() {
    }

    public UsuariosException(String mensaje) {
        super(mensaje);
    }

    public UsuariosException(String mensaje, Throwable cause) {
        super(mensaje, cause);
    }
}
