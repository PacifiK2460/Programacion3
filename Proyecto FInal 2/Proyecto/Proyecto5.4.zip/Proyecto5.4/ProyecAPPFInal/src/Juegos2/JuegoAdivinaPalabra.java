package Juegos2;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;

public class JuegoAdivinaPalabra extends JFrame{
    private JFrame frame;
    private JPanel panel;
    private JLabel palabraPortuguesLabel;
    private JComboBox<String> opcionesComboBox;
    private JButton verificarButton;
    private int palabrasCorrectas;

    private Map<String, String> palabras;

    public JuegoAdivinaPalabra() {
        // Inicializar el contador de palabras correctas
        palabrasCorrectas = 0;

        // Crear el diccionario de palabras a adivinar
        palabras = new HashMap<>();
        palabras.put("casa", "casa");
        palabras.put("perro", "cachorro");
        palabras.put("ordenador", "computadora");
        palabras.put("gato", "gato");
        palabras.put("jardín", "jardín");
        palabras.put("libro", "libro");
        palabras.put("playa", "playa");
        palabras.put("sol", "sol");
        palabras.put("amigo", "amigo");
        palabras.put("comida", "comida");

        // Crear la ventana principal
        frame = new JFrame("Juego de Adivina la Palabra");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 200);
        frame.setLayout(new FlowLayout());

        // Crear el panel
        panel = new JPanel();
        panel.setLayout(new GridLayout(2, 2));

        // Crear los componentes
        palabraPortuguesLabel = new JLabel();
        opcionesComboBox = new JComboBox<>(new String[]{"", "", "", ""});
        verificarButton = new JButton("Verificar");

        // Agregar los componentes al panel
        panel.add(new JLabel("Palabra en Portugués:"));
        panel.add(palabraPortuguesLabel);
        panel.add(new JLabel("Traducción en Español:"));
        panel.add(opcionesComboBox);

        // Agregar el panel y el botón al contenedor
        frame.add(panel);
        frame.add(verificarButton);

        // Asociar el evento de clic al botón "Verificar"
        verificarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                verificarRespuesta();
            }
        });

        // Mostrar la ventana principal
        frame.setVisible(true);

        // Iniciar el juego
        iniciarJuego();
    }

    private void iniciarJuego() {
        // Obtener palabras aleatorias para el juego actual
        ArrayList<String> palabrasPortugues = new ArrayList<>(palabras.keySet());
        Collections.shuffle(palabrasPortugues);
        palabrasPortugues = new ArrayList<>(palabrasPortugues.subList(0, 4));

        // Mostrar la primera palabra en portugués
        palabraPortuguesLabel.setText(palabrasPortugues.get(0));

        // Obtener las opciones en español para el ComboBox
        String traduccionCorrecta = palabras.get(palabrasPortugues.get(0));
        ArrayList<String> opciones = new ArrayList<>(palabras.values());
        opciones.remove(traduccionCorrecta);
        Collections.shuffle(opciones);
        opciones = new ArrayList<>(opciones.subList(0, 3));
        opciones.add(traduccionCorrecta);
        Collections.shuffle(opciones);

        // Actualizar las opciones en el ComboBox
        opcionesComboBox.setModel(new DefaultComboBoxModel<>(opciones.toArray(new String[0])));
    }

    private void verificarRespuesta() {
        String palabraPortugues = palabraPortuguesLabel.getText();
        String traduccionSeleccionada = opcionesComboBox.getSelectedItem().toString();

        if (palabras.get(palabraPortugues).equals(traduccionSeleccionada)) {
            palabrasCorrectas++;
        }

        if (palabrasCorrectas >= 4) {
            JOptionPane.showMessageDialog(null, "¡Felicidades! Has adivinado al menos 4 palabras. ¡Lo has logrado!");
            abrirVentanaSiguiente();
        } else {
            int opcion = JOptionPane.showOptionDialog(null, "No has logrado adivinar al menos 4 palabras. ¿Deseas intentarlo de nuevo?", "Juego de Adivina la Palabra", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, null, null);

            if (opcion == JOptionPane.YES_OPTION) {
                reiniciarJuego();
            } else {
                System.exit(0);
            }
        }
    }

    private void abrirVentanaSiguiente() {
        JFrame ventanaSiguiente = new JFrame("Siguiente Ventana");
        ventanaSiguiente.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ventanaSiguiente.setSize(400, 200);
       ventanaSiguiente.setLayout(new FlowLayout());

        JLabel label = new JLabel("¡Felicidades! Has adivinado al menos 4 palabras. ¡Lo has logrado!");
        ventanaSiguiente.add(label);

        ventanaSiguiente.setVisible(true);
    }

    private void reiniciarJuego() {
        palabrasCorrectas = 0;
        iniciarJuego();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new JuegoAdivinaPalabra();
            }
        });
    }
}