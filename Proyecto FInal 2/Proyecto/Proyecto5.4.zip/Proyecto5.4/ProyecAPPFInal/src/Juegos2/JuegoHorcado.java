package Juegos2;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

public class JuegoHorcado extends JFrame{
    private JFrame frame;
    private JLabel palabraLabel;
    private JTextField respuestaTextField;
    private JButton verificarButton;
    private int juegosCompletados;

    private String[] palabras = {
            "casa", "perro", "ordenador", "gato", "jardín",
            "libro", "playa", "sol", "amigo", "comida"
    };

    private int indicePalabraActual;
    private int intentosRestantes;

    public JuegoHorcado() {
        // Inicializar el contador de juegos completados y el índice de la palabra actual
        juegosCompletados = 0;
        indicePalabraActual = 0;

        // Crear la ventana principal
        frame = new JFrame("Juego del Horcado");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 200);
        frame.setLayout(new FlowLayout());

        // Crear los componentes
        palabraLabel = new JLabel();
        respuestaTextField = new JTextField(10);
        verificarButton = new JButton("Verificar");

        // Agregar los componentes al contenedor
        frame.add(palabraLabel);
        frame.add(respuestaTextField);
        frame.add(verificarButton);

        // Asociar el evento de clic al botón "Verificar"
        verificarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                verificarRespuesta();
            }
        });

        // Mostrar la ventana principal
        frame.setVisible(true);

        // Iniciar el primer juego
        iniciarJuego();
    }

    private void iniciarJuego() {
        if (juegosCompletados < 5) {
            // Seleccionar una palabra aleatoria
            Random rand = new Random();
            indicePalabraActual = rand.nextInt(palabras.length);

            // Mostrar la palabra como guiones bajos
            StringBuilder palabraOculta = new StringBuilder();
            for (int i = 0; i < palabras[indicePalabraActual].length(); i++) {
                palabraOculta.append("_");
            }
            palabraLabel.setText(palabraOculta.toString());

            // Reiniciar el contador de intentos restantes
            intentosRestantes = 5;
        } else {
            terminarJuego();
        }
    }

    private void verificarRespuesta() {
        String respuesta = respuestaTextField.getText().toLowerCase();

        if (respuesta.equals(palabras[indicePalabraActual])) {
            JOptionPane.showMessageDialog(null, "¡Respuesta correcta! Has adivinado la palabra.");
            juegosCompletados++;
            iniciarJuego();
        } else {
            intentosRestantes--;
            if (intentosRestantes > 0) {
                JOptionPane.showMessageDialog(null, "Respuesta incorrecta. Te quedan " + intentosRestantes + " intentos.");
            } else {
                JOptionPane.showMessageDialog(null, "Respuesta incorrecta. Se acabaron los intentos. La palabra era: " + palabras[indicePalabraActual]);
                juegosCompletados++;
                iniciarJuego();
            }
        }
    }

    private void terminarJuego() {
        frame.dispose();

        if (juegosCompletados >= 4) {
            JOptionPane.showMessageDialog(null, "¡Felicidades! Has completado al menos 4 juegos. ¡Lo has conseguido!");
            abrirVentanaSiguiente();
        } else {
            int opcion = JOptionPane.showOptionDialog(null, "No has logrado completar al menos 4 juegos. ¿Deseas volver a intentarlo o salir del juego?", "Juego del Horcado", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, null, null);

            if (opcion == JOptionPane.YES_OPTION) {
                new JuegoHorcado();
            } else {
                System.exit(0);
            }
        }
    }

    private void abrirVentanaSiguiente() {
        JFrame ventanaSiguiente = new JFrame("Siguiente Ventana");
        ventanaSiguiente.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ventanaSiguiente.setSize(400, 200);
        ventanaSiguiente.setLayout(new FlowLayout());

        JLabel label = new JLabel("¡Felicidades! Has completado al menos 4 juegos. ¡Lo has conseguido!");
        ventanaSiguiente.add(label);

        ventanaSiguiente.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new JuegoHorcado().setVisible(true);
            }
        });
    }
}