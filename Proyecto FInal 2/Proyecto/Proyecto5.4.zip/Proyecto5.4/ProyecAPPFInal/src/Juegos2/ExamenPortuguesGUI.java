/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Juegos2;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class ExamenPortuguesGUI extends JFrame implements ActionListener {
    private List<Pregunta> preguntas;
    private JLabel preguntaLabel;
    private JButton[] opcionesButtons;
    private int indicePregunta;
    private int respuestasCorrectas;

    public ExamenPortuguesGUI() {
        setTitle("Examen de Portugués");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);
        setLayout(new BorderLayout());

        preguntaLabel = new JLabel();
        preguntaLabel.setHorizontalAlignment(JLabel.CENTER);
        add(preguntaLabel, BorderLayout.CENTER);

        JPanel opcionesPanel = new JPanel(new GridLayout(2, 2));
        opcionesButtons = new JButton[4];
        for (int i = 0; i < opcionesButtons.length; i++) {
            opcionesButtons[i] = new JButton();
            opcionesButtons[i].addActionListener(this);
            opcionesPanel.add(opcionesButtons[i]);
        }
        add(opcionesPanel, BorderLayout.SOUTH);

        preguntas = new ArrayList<>();
        preguntas.add(new Pregunta("O que significa 'obrigado' em português?", new String[]{"Obrigado", "Bom dia", "Por favor", "Tchau"}, 0));
        preguntas.add(new Pregunta("Qual é a capital do Brasil?", new String[]{"São Paulo", "Brasília", "Rio de Janeiro", "Salvador"}, 1));
        // Agrega las preguntas restantes

        indicePregunta = 0;
        respuestasCorrectas = 0;
        mostrarSiguientePregunta();
    }

    private void mostrarSiguientePregunta() {
        if (indicePregunta < preguntas.size()) {
            Pregunta pregunta = preguntas.get(indicePregunta);
            preguntaLabel.setText(pregunta.getPregunta());
            for (int i = 0; i < opcionesButtons.length; i++) {
                opcionesButtons[i].setText(pregunta.getOpciones()[i]);
            }
        } else {
            mostrarResultadoFinal();
        }
    }

    private void mostrarResultadoFinal() {
        if (respuestasCorrectas >= 9) {
            JOptionPane.showMessageDialog(this, "¡Felicitaciones! Has respondido correctamente a " + respuestasCorrectas + " preguntas. Aprobaste el examen.");
            // Aquí puedes abrir la siguiente ventana o realizar cualquier otra acción deseada
            // En este ejemplo, simplemente se cierra la ventana principal
            dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Has respondido correctamente a " + respuestasCorrectas + " preguntas. No has aprobado el examen.");
            // Aquí puedes abrir la siguiente ventana o realizar cualquier otra acción deseada
            // En este ejemplo, simplemente se cierra la ventana principal
            dispose();
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        JButton botonPresionado = (JButton) e.getSource();
        int opcionSeleccionada = -1;
        for (int i = 0; i < opcionesButtons.length; i++) {
            if (botonPresionado == opcionesButtons[i]) {
                opcionSeleccionada = i;
                break;
            }
        }

        Pregunta preguntaActual = preguntas.get(indicePregunta);
        if (opcionSeleccionada == preguntaActual.getIndiceRespuestaCorrecta()) {
            respuestasCorrectas++;
        }

        indicePregunta++;
        mostrarSiguientePregunta();
    }

    private class Pregunta {
        private String pregunta;
        private String[] opciones;
        private int indiceRespuestaCorrecta;

        public Pregunta(String pregunta, String[] opciones, int indiceRespuestaCorrecta) {
            this.pregunta = pregunta;
            this.opciones = opciones;
            this.indiceRespuestaCorrecta = indiceRespuestaCorrecta;
        }

        public String getPregunta() {
            return pregunta;
        }

        public String[] getOpciones() {
            return opciones;
        }

        public int getIndiceRespuestaCorrecta() {
            return indiceRespuestaCorrecta;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                ExamenPortuguesGUI examenPortuguesGUI = new ExamenPortuguesGUI();
                examenPortuguesGUI.setVisible(true);
            }
        });
    }
}