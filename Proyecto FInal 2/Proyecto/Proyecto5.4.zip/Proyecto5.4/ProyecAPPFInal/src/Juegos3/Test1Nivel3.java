package Juegos3;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Test1Nivel3 extends JFrame {
    private JFrame frame;
    private JLabel preguntaLabel;
    private JRadioButton opcion1RadioButton;
    private JRadioButton opcion2RadioButton;
    private JRadioButton opcion3RadioButton;
    private JButton siguienteButton;
    private int respuestasCorrectas;

    private String[][] preguntas = {
        {"¿Cómo se dice 'hola' en portugués?", "A) Obrigado", "B) Olá", "C) Bom dia", "B"},
        {"¿Cuál es la traducción de 'amigo' en portugués?", "A) Amigo", "B) Casa", "C) Carro", "A"},
        {"¿Cómo se dice 'gracias' en portugués?", "A) Desculpe", "B) Obrigado", "C) Sim", "B"},
        {"¿Cuál es la traducción de 'perro' en portugués?", "A) Gato", "B) Cachorro", "C) Livro", "B"},
        {"¿Cómo se dice 'buenos días' en portugués?", "A) Boa tarde", "B) Bom dia", "C) Boa noite", "B"},
        {"¿Cuál es la traducción de 'comer' en portugués?", "A) Comer", "B) Beber", "C) Dormir", "A"},
        {"¿Cómo se dice 'rojo' en portugués?", "A) Azul", "B) Vermelho", "C) Verde", "B"},
        {"¿Cuál es la traducción de 'libro' en portugués?", "A) Livro", "B) Casa", "C) Carro", "A"},
        {"¿Cómo se dice 'adiós' en portugués?", "A) Tchau", "B) Oi", "C) Até logo", "A"},
        {"¿Cuál es la traducción de 'agua' en portugués?", "A) Fogo", "B) Ar", "C) Água", "C"}
    };

    private int preguntaActual;
    
    public Test1Nivel3() {
        // Inicializar el contador de respuestas correctas
        respuestasCorrectas = 0;
        this.setVisible(false);
        // Crear la ventana principal
        frame = new JFrame("Test de Portugués");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);
        frame.setLayout(new BorderLayout());
        frame.setLocationRelativeTo(null);

        // Crear el panel para la pregunta
        JPanel preguntaPanel = new JPanel(new GridLayout(2, 1));
        preguntaLabel = new JLabel();
        preguntaPanel.add(preguntaLabel);

        // Crear el panel para las opciones
        JPanel opcionesPanel = new JPanel(new GridLayout(3, 1));
        opcion1RadioButton = new JRadioButton();
        opcion2RadioButton = new JRadioButton();
        opcion3RadioButton = new JRadioButton();
        ButtonGroup grupoOpciones = new ButtonGroup();
        grupoOpciones.add(opcion1RadioButton);
        grupoOpciones.add(opcion2RadioButton);
        grupoOpciones.add(opcion3RadioButton);
        opcionesPanel.add(opcion1RadioButton);
        opcionesPanel.add(opcion2RadioButton);
        opcionesPanel.add(opcion3RadioButton);

        // Crear el panel para el botón siguiente
        JPanel siguientePanel = new JPanel();
        siguienteButton = new JButton("Siguiente");
        siguientePanel.add(siguienteButton);

        // Agregar los paneles al contenedor principal
        frame.add(preguntaPanel, BorderLayout.NORTH);
        frame.add(opcionesPanel, BorderLayout.CENTER);
        frame.add(siguientePanel, BorderLayout.SOUTH);

        // Mostrar la primera pregunta
        mostrarPregunta(0);

        // Agregar el ActionListener al botón siguiente
        siguienteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                comprobarRespuesta();
                if (preguntaActual < preguntas.length - 1) {
                    mostrarPregunta(preguntaActual + 1);
                } else {
                    finalizarTest();
                }
            }
        });
        
        // Mostrar la ventana principal
       frame.setVisible(true);
    }

    private void mostrarPregunta(int indice) {
        preguntaActual = indice;
        String pregunta = preguntas[indice][0];
        String opcion1 = preguntas[indice][1];
        String opcion2 = preguntas[indice][2];
        String opcion3 = preguntas[indice][3];

        preguntaLabel.setText(pregunta);
        opcion1RadioButton.setText(opcion1);
        opcion2RadioButton.setText(opcion2);
        opcion3RadioButton.setText(opcion3);

        // Reiniciar la selección de las opciones
        opcion1RadioButton.setSelected(false);
        opcion2RadioButton.setSelected(false);
        opcion3RadioButton.setSelected(false);
    }

    private void comprobarRespuesta() {
        String respuestaCorrecta = preguntas[preguntaActual][4];
        if (opcion1RadioButton.isSelected() && respuestaCorrecta.equals("A")) {
            respuestasCorrectas++;
        } else if (opcion2RadioButton.isSelected() && respuestaCorrecta.equals("B")) {
            respuestasCorrectas++;
        } else if (opcion3RadioButton.isSelected() && respuestaCorrecta.equals("C")) {
            respuestasCorrectas++;
        }
    }

    private void finalizarTest() {
        if (respuestasCorrectas >= 8) {
            JOptionPane.showMessageDialog(frame, "¡Felicidades! Has superado el test y estás listo para la siguiente lección.", "¡Test Superado!", JOptionPane.INFORMATION_MESSAGE);
           
            frame.setVisible(false);
            this.setVisible(false);
            //abrirSiguienteVentana();
        } else {
            JOptionPane.showMessageDialog(frame, "No has logrado completar el curso anterior. Necesitas repasar.", "¡Test No Superado!", JOptionPane.INFORMATION_MESSAGE);
            abrirOtraVentana();
        }
        
    }

    private void abrirSiguienteVentana() {
        // Crear la segunda ventana
        JFrame siguienteVentana = new JFrame("Siguiente Lección");
        siguienteVentana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        siguienteVentana.setSize(300, 200);
        siguienteVentana.setLocationRelativeTo(null);
        

        // Crear los componentes de la segunda ventana
        JLabel label = new JLabel("¡Enhorabuena! Has superado el test y estás listo para la siguiente lección.");
        JButton button = new JButton("Cerrar");

        // Agregar los componentes a la segunda ventana
        siguienteVentana.getContentPane().add(label, BorderLayout.CENTER);
        siguienteVentana.getContentPane().add(button, BorderLayout.SOUTH);

        // Agregar el ActionListener al botón de la segunda ventana para cerrarla
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                siguienteVentana.dispose();
            }
        });

        // Mostrar la segunda ventana
        siguienteVentana.setVisible(true);
    }

    private void abrirOtraVentana() {
        // Crear la tercera ventana
        JFrame otraVentana = new JFrame("Otra Ventana");
        otraVentana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        otraVentana.setSize(300, 200);
        otraVentana.setLocationRelativeTo(null);
        // Crear los componentes de la tercera ventana
        JLabel label = new JLabel("No has logrado completar el curso anterior. Necesitas repasar.");
        JButton button = new JButton("Cerrar");

        // Agregar los componentes a la tercera ventana
        otraVentana.getContentPane().add(label, BorderLayout.CENTER);
        otraVentana.getContentPane().add(button, BorderLayout.SOUTH);

        // Agregar el ActionListener al botón de la tercera ventana para cerrarla
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                otraVentana.dispose();
            }
        });

        // Mostrar la tercera ventana
        otraVentana.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                
                new Test1Nivel3().setVisible(true);
            }
        });
    }

   
}