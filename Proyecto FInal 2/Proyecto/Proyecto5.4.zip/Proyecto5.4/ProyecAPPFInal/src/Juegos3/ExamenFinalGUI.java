package Juegos3;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;



import javax.swing.SwingUtilities;

public class ExamenFinalGUI extends JFrame implements ActionListener {
    private List<Pregunta> preguntas;
    private JLabel preguntaLabel;
    private JTextField respuestaField;
    private JButton enviarButton;
    private JLabel incorrectasLabel;
    private int indicePregunta;
    private int preguntasCorrectas;

    public ExamenFinalGUI() {
        setTitle("Examen Final");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 100);
        setLayout(new BorderLayout());
        this.setLocationRelativeTo(null);

        preguntaLabel = new JLabel();
        preguntaLabel.setHorizontalAlignment(JLabel.CENTER);
        add(preguntaLabel, BorderLayout.CENTER);

        JPanel respuestaPanel = new JPanel(new FlowLayout());
        JLabel respuestaLabel = new JLabel("Traducción al español:");
        respuestaField = new JTextField(20);
        enviarButton = new JButton("Enviar");
        enviarButton.addActionListener(this);
        respuestaPanel.add(respuestaLabel);
        respuestaPanel.add(respuestaField);
        respuestaPanel.add(enviarButton);
        add(respuestaPanel, BorderLayout.SOUTH);

        incorrectasLabel = new JLabel();
        incorrectasLabel.setHorizontalAlignment(JLabel.CENTER);
        add(incorrectasLabel, BorderLayout.NORTH);

        preguntas = new ArrayList<>();
        preguntas.add(new Pregunta("casa", "casa")); // Ejemplo de pregunta y respuesta
        preguntas.add(new Pregunta("perro", "Cao")); // Ejemplo de pregunta y respuesta
       
        




// Agrega las preguntas restantes

        indicePregunta = 0;
        preguntasCorrectas = 0;
        mostrarSiguientePregunta();
    }

    private void mostrarSiguientePregunta() {
        if (indicePregunta < preguntas.size()) {
            Pregunta pregunta = preguntas.get(indicePregunta);
            preguntaLabel.setText(pregunta.getPregunta());
            respuestaField.setText("");
            respuestaField.setEnabled(true);
            enviarButton.setEnabled(true);
        } else {
            mostrarResultadoFinal();
        }
    }

    private void mostrarResultadoFinal() {
        respuestaField.setEnabled(false);
        enviarButton.setEnabled(false);

        if (preguntasCorrectas >= 45) {
            JOptionPane.showMessageDialog(this, "¡Felicitaciones! Has respondido correctamente a " + preguntasCorrectas + " preguntas. Parabéns!");
            // Aquí puedes abrir la siguiente ventana o realizar cualquier otra acción deseada
            // En este ejemplo, simplemente se cierra la ventana principal
            dispose();
        } else if (preguntasCorrectas >= 40) {
            int opcion = JOptionPane.showConfirmDialog(this, "Has respondido correctamente a " + preguntasCorrectas + " preguntas. ¿Deseas intentarlo de nuevo?", "Intentar de nuevo", JOptionPane.YES_NO_OPTION);
            if (opcion == JOptionPane.YES_OPTION) {
                reiniciarExamen();
            } else {
                dispose();
            }
        } else {
            JOptionPane.showMessageDialog(this, "Has respondido correctamente a " + preguntasCorrectas + " preguntas. Necesitas estudiar más...");
            // Aquí puedes abrir la siguiente ventana o realizar cualquier otra acción deseada
            // En este ejemplo, simplemente se cierra la ventana principal
            dispose();
        }
    }

    private void reiniciarExamen() {
        Collections.shuffle(preguntas);
        indicePregunta = 0;
        preguntasCorrectas = 0;
        incorrectasLabel.setText("");
        mostrarSiguientePregunta();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String respuesta = respuestaField.getText().trim().toLowerCase();
        Pregunta preguntaActual = preguntas.get(indicePregunta);
        if (respuesta.equals(preguntaActual.getRespuesta())) {
            preguntasCorrectas++;
        } else {
            String incorrectasText = incorrectasLabel.getText();
            if (!incorrectasText.isEmpty()) {
                incorrectasText += ", ";
            }
            incorrectasText += String.valueOf(indicePregunta + 1);
            incorrectasLabel.setText(incorrectasText);
            incorrectasLabel.setForeground(Color.RED);
        }

        indicePregunta++;
        mostrarSiguientePregunta();
    }

    private class Pregunta {
        private String pregunta;
        private String respuesta;

        public Pregunta(String pregunta, String respuesta) {
            this.pregunta = pregunta;
            this.respuesta = respuesta;
        }

        public String getPregunta() {
            return pregunta;
        }

        public String getRespuesta() {
            return respuesta;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                ExamenFinalGUI examenFinalGUI = new ExamenFinalGUI();
                examenFinalGUI.setVisible(true);
            }
         });
    }
}