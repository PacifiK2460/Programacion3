package Juegos;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
/**
 * @author 177557
 */
public class JuegoPalabras {
    private JFrame frame;
    private JLabel label;
    private JTextField textField;
    private JButton button;
    private int intentos;

    private List<String> palabras = Arrays.asList("cadeira", "livro", "mesa", "computador", "carro");
    private String palabraDesordenada;
    private String palabraOrdenada;

    public JuegoPalabras() {
        // Inicializar el contador de intentos
        intentos = 0;

        // Crear la ventana principal
        frame = new JFrame("Juego de Palabras");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 200);
        frame.setLayout(new FlowLayout());
        

        // Crear los componentes
        label = new JLabel("Acomoda la palabra desordenada:");
        textField = new JTextField(15);
        button = new JButton("Comprobar");

        // Agregar los componentes al contenedor
        frame.add(label);
        frame.add(textField);
        frame.add(button);

        // Generar la palabra desordenada al iniciar el juego
        generarPalabraDesordenada();

        // Agregar el ActionListener al botón
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                comprobarPalabra();
            }
        });

        // Mostrar la ventana principal
        frame.setVisible(true);
        
    }

    private void generarPalabraDesordenada() {
        Collections.shuffle(palabras);
        palabraDesordenada = palabras.get(0);
        palabraOrdenada = ordenarPalabra(palabraDesordenada);
    }

    private String ordenarPalabra(String palabra) {
        char[] letras = palabra.toCharArray();
        Arrays.sort(letras);
        return new String(letras);
    }

    private void comprobarPalabra() {
        intentos++;
        String palabraIngresada = textField.getText().toLowerCase();

        if (palabraIngresada.equals(palabraOrdenada)) {
            JOptionPane.showMessageDialog(frame, "¡Correcto! Has ordenado la palabra correctamente.");
            abrirSegundaVentana();
        } else {
            if (intentos >= 3) {
                JOptionPane.showMessageDialog(frame, "Lo siento, no has logrado ordenar la palabra correctamente. ¡Sigue intentando!");
                reiniciarJuego();
            } else {
                JOptionPane.showMessageDialog(frame, "La palabra no está ordenada correctamente. Sigue intentando.");
                textField.setText("");
            }
        }
    }

    private void reiniciarJuego() {
        intentos = 0;
        textField.setText("");
        generarPalabraDesordenada();
    }

    private void abrirSegundaVentana() {
        // Crear la segunda ventana
        JFrame segundaVentana = new JFrame("Segunda Ventana");
        segundaVentana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        segundaVentana.setSize(300, 200);
        segundaVentana.setLayout(new FlowLayout());

        // Crear los componentes de la segunda ventana
        JLabel label2 = new JLabel("¡Has completado el juego!");
        JButton button2 = new JButton("Cerrar");

        // Agregar los componentes a la segunda ventana
        segundaVentana.add(label2);
        segundaVentana.add(button2);

        // Agregar el ActionListener al botón de la segunda ventana para cerrarla
        button2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                segundaVentana.dispose();
            }
        });

        // Mostrar la segunda ventana
        segundaVentana.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new JuegoPalabras();
            }
        });
    }
}

