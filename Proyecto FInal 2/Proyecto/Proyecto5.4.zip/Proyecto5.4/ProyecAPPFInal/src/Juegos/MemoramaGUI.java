package Juegos;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MemoramaGUI extends JFrame implements ActionListener {
    private List<String> palabras;
    private List<JButton> botones;
    private JButton primerBoton;
    private int intentos;
    private int paresCorrectos;
    private JTextField textCorrectos;
    private JTextField textErrores;

    public MemoramaGUI() {
        setTitle("Memorama Game");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);
        setLayout(new GridLayout(4, 4));
        this.setLocationRelativeTo(null);

        palabras = new ArrayList<>();
        palabras.add("Casa"); // Palabra en portugués
        palabras.add("Casa"); // Traducción en español
        palabras.add("Perro"); // Palabra en portugués
        palabras.add("Perro"); // Traducción en español
        palabras.add("Gato"); // Palabra en portugués
        palabras.add("Gato"); // Traducción en español
        palabras.add("Sol"); // Palabra en portugués
        palabras.add("Sol"); // Traducción en español
        palabras.add("Árbol"); // Palabra en portugués
        palabras.add("Árbol"); // Traducción en español
        palabras.add("Luna"); // Palabra en portugués
        palabras.add("Luna"); // Traducción en español

        botones = new ArrayList<>();
        for (int i = 0; i < 12; i++) {
            JButton boton = new JButton();
            boton.addActionListener(this);
            botones.add(boton);
            add(boton);
        }

        textCorrectos = new JTextField();
        textCorrectos.setEditable(false);
        add(textCorrectos);

        textErrores = new JTextField();
        textErrores.setEditable(false);
        add(textErrores);

        iniciarJuego();
    }

    private void iniciarJuego() {
        Collections.shuffle(palabras);
        for (int i = 0; i < 12; i++) {
            botones.get(i).setText(palabras.get(i));
            botones.get(i).setEnabled(true);
        }

        primerBoton = null;
        intentos = 0;
        paresCorrectos = 0;
        textCorrectos.setText("Correctos: " + paresCorrectos);
        textErrores.setText("Errores: " + intentos);
    }

    private void bloquearBotones() {
        for (JButton boton : botones) {
            boton.setEnabled(false);
        }
    }

    private void comprobarPares(JButton segundoBoton) {
        String palabra1 = primerBoton.getText();
        String palabra2 = segundoBoton.getText();

        if (palabra1.equals(palabra2)) {
            primerBoton.setBackground(Color.GREEN);
            segundoBoton.setBackground(Color.GREEN);
            paresCorrectos++;

            if (paresCorrectos == 6) {
                JOptionPane.showMessageDialog(this, "¡Felicidades! Has completado todos los pares correctamente.");
                 Lectura Ex = new Lectura();
                 Ex.setVisible(true);
                this.setVisible(false);
                
            }
        } else {
            primerBoton.setBackground(null);
            segundoBoton.setBackground(null);
            intentos++;

            if (intentos == 3) {
                bloquearBotones();
                int opcion = JOptionPane.showConfirmDialog(this, "Has alcanzado 3 errores. ¿Deseas jugar de nuevo?", "Reiniciar", JOptionPane.YES_NO_OPTION);
                if (opcion == JOptionPane.YES_OPTION) {
                   iniciarJuego();
                } else {
                    System.exit(0);
                }
            }
        }

        primerBoton = null;
        textCorrectos.setText("Correctos: " + paresCorrectos);
        textErrores.setText("Errores: " + intentos);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        JButton boton = (JButton) e.getSource();

        if (primerBoton == null) {
            primerBoton = boton;
            boton.setEnabled(false);
        } else {
            boton.setEnabled(false);
            comprobarPares(boton);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                MemoramaGUI memorama = new MemoramaGUI();
                memorama.setVisible(true);
            }
        });
    }
}