package Juegos;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Lectura extends JFrame {
    private JTextArea textArea;
    private JTextField respuestaField;
    private int preguntasCorrectas;

    public Lectura() {
        setTitle("Lectura y Preguntas");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 200);
        setLayout(new BorderLayout());

        textArea = new JTextArea();
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
        JScrollPane scrollPane = new JScrollPane(textArea);
        add(scrollPane, BorderLayout.CENTER);

        JPanel respuestaPanel = new JPanel(new FlowLayout());
        JLabel respuestaLabel = new JLabel("Traducción al español:");
        respuestaField = new JTextField(20);
        JButton enviarButton = new JButton("Enviar");
        enviarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String respuesta = respuestaField.getText().trim().toLowerCase();
                boolean respuestaCorrecta = comprobarRespuesta(respuesta);
                if (respuestaCorrecta) {
                    preguntasCorrectas++;
                    if (preguntasCorrectas >= 4) {
                        mostrarSiguienteVentana();
                    } else {
                        mostrarSiguienteLectura();
                    }
                } else {
                    mostrarLecturaActual();
                }
            }
        });
        respuestaPanel.add(respuestaLabel);
        respuestaPanel.add(respuestaField);
        respuestaPanel.add(enviarButton);
        add(respuestaPanel, BorderLayout.SOUTH);

        preguntasCorrectas = 0;
        mostrarSiguienteLectura();
    }

    private void mostrarSiguienteLectura() {
        String lectura = obtenerSiguienteLectura();
        textArea.setText(lectura);
        respuestaField.setText("");
        respuestaField.requestFocus();
    }

    private String obtenerSiguienteLectura() {
        // Aquí puedes implementar la lógica para obtener la siguiente lectura en portugués
        // Puedes leerla desde un archivo, una base de datos, etc.
        // En este ejemplo, he utilizado textos de ejemplo para las lecturas
        String[] lecturas = {
                
                "A casa é verde", // La casa es verde.
                "O carro é vermelho.", // El carro es rojo.
                "Eu gosto de música.", // Me gusta la música.
                "Eu tenho 2 irmãos",
                "Eu leo o jornal",
                "Eles comen a salada",
        };
        return lecturas[preguntasCorrectas];
    }

    private boolean comprobarRespuesta(String respuesta) {
        // Aquí debes implementar la lógica para comprobar si la respuesta es correcta
        // Puedes compararla con la respuesta esperada, realizar una consulta a una base de datos, etc.
        // En este ejemplo, he utilizado respuestas de ejemplo para las preguntas
        String[] respuestas = {
                "la casa es verde",
                "el carro es rojo",
                "me gusta la musica",
                "tengo 2 hermanos",
                "leo el periodico",
                "ellos comen ensalada"
        };
        String respuestaEsperada = respuestas[preguntasCorrectas];
        return respuesta.equals(respuestaEsperada);
    }

    private void mostrarLecturaActual() {
        JOptionPane.showMessageDialog(this, "Respuesta incorrecta. Por favor, inténtalo de nuevo.");
        mostrarSiguienteLectura();
    }

    private void mostrarSiguienteVentana() {
        JOptionPane.showMessageDialog(this, "¡Felicidades! Has respondido correctamente a todas las preguntas.");
        // Aquí puedes abrir la siguiente ventana o realizar cualquier otra acción deseada
        // En este ejemplo, simplemente se cierra la ventana principal
        Examen1 e1 = new Examen1();
        dispose();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                Lectura lecturaGUI = new Lectura();
                lecturaGUI.setVisible(true);
            }
        });
    }
}
