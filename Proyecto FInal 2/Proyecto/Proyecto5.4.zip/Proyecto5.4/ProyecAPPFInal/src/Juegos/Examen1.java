package Juegos;
import CuadroPalabras.Nivel1Parte1;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * @author 177815
 */
public class Examen1 extends JFrame{
    private JFrame frame;
    private JPanel panel;
    private JLabel preguntaLabel, respuestaLabel, resultadoLabel;
    private JTextField respuestaField;
    private JButton verificarButton;
    
    private String[] preguntas = {
        "O que significa 'amigo' em português?",
        "Como se diz 'casa' em português?",
        "Traduza 'comida' para o português.",
        "Qual é a tradução de 'sol'?",
        "Como se escreve 'carro' em português?",
        "Traduza 'água' para o português.",
        "O que significa 'noite'?",
        "Como se diz 'trabajo' em português?",
        "Qual é a tradução de 'família'?",
        "Traduza 'Segunda-Feira' para o português."
    };
    
    private String[] respostas = {
        "amigo", "lar", "refeicao", "sol", "auto", "agua", "noche", "trabalho", "família", "lunes"
    };
    
    private int contadorPreguntas;
    private int respostasCorretas;
    
    public Examen1() {
        frame = new JFrame("Examen de Portugués");
        panel = new JPanel();
        preguntaLabel = new JLabel("");
        respuestaLabel = new JLabel("Resposta:");
        resultadoLabel = new JLabel("");
        respuestaField = new JTextField(20);
        verificarButton = new JButton("Verificar");
        
        contadorPreguntas = 0;
        respostasCorretas = 0;
        
        verificarButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                verificarResposta();
            }
        });
        
        panel.setLayout(new GridLayout(5, 1));
        panel.add(preguntaLabel);
        panel.add(respuestaLabel);
        panel.add(respuestaField);
        panel.add(verificarButton);
        panel.add(resultadoLabel);
        
        frame.add(panel);
        frame.setSize(400, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
        
        mostrarPergunta();
    }
    
    private void mostrarPergunta() {
        if (contadorPreguntas < preguntas.length) {
            preguntaLabel.setText(preguntas[contadorPreguntas]);
            respuestaField.setText("");
        } else {
            finalizarExamen();
        }
    }
    
    private void verificarResposta() {
        String respostaUsuario = respuestaField.getText().trim();
        String respostaCorreta = respostas[contadorPreguntas];
        
        if (respostaUsuario.equalsIgnoreCase(respostaCorreta)) {
            respostasCorretas++;
        }
        
        contadorPreguntas++;
        mostrarPergunta();
    }
    
    private void finalizarExamen() {
        if (respostasCorretas >= 8) {
            JOptionPane.showMessageDialog(this, "Parabéns! Você foi aprovado no exame");
            JuegoPalabras JP = new JuegoPalabras();
            this.setVisible(false);
            respuestaLabel.setVisible(false);
            respuestaField.setVisible(false);
            verificarButton.setVisible(false);
            setVisible(false);
            
        } else {
            resultadoLabel.setText("Você não atingiu a pontuação necessária no exame.");
            Nivel1Parte1 n1 = new Nivel1Parte1();
            n1.setVisible(true);
            respuestaLabel.setVisible(false);
            respuestaField.setVisible(false);
            verificarButton.setVisible(false);
            dispose();
            setVisible(false);
        }
        
        respuestaLabel.setVisible(false);
        respuestaField.setVisible(false);
        verificarButton.setVisible(false);
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new Examen1();
            }
        });
    }
}

