package FinalProyect;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TestPortugues extends JFrame {
    private int preguntasCorrectas;
    private String[][] preguntasRespuestas = {
        {"¿Cómo se dice 'hola' en portugués?", "Olá"},
        {"¿Cuál es el verbo 'hablar' en portugués?", "Falar"},
        {"¿Qué significa 'obrigado' en español?", "Gracias"},
        {"¿Cuál es el artículo definido en portugués para 'el'?", "O"},
        {"Como vai?", "Todu bem"},
        {"Qual é a tradução de abacaxi?", "Piña"},
        {"¿Como puedo decir que estoy 'En la'?", "No"},
        {"Eu tenho uma aranha do color 'Rojo'", "vermelho"},
        {"¿Cuál es el artículo definido en portugués para 'ella'?", "Ela"},
  /*10*/{"¿Cuál es el artículo definido en Español para 'Ele'?", "El"},
        {"¿Você pode tradução a palavra 'Leao'?", "leon"},
        {"¿Você pode tradução a palavra 'Segunda-feira'?", "Lunes"},
        {"A verdade é que não o vejo desde 'terça-feira'", "Martes"},
        {"¿Você pode tradução a palavra de espanhol do portugues 'Sabado'?", "Sabado"},
        {"¿Como se escreve a palavra 'Periodico'?", "Jornal"},
        {"Qual e a forma mais facil de decir 'Estou'?", "To"},
        {"Voce vai querer um desse ou 'deste'?", "De ellos"},
        {"¿Você pode fazer meu filme com seu 'chefe'?", "Cocinero"},
        {"Tá 'ligado' aquele restaurante que fica na esquina daqui de casa?", "Conectado"},
        {" 'Tá tá', entendi.", "Vale"},  
        // Agrega más preguntas y respuestas aquí
    };
    private JPanel panelPreguntasRespuestas; // Variable de instancia para el panel de preguntas y respuestas

    public TestPortugues() {
        preguntasCorrectas = 0;

        // Configuración de la ventana principal
        setTitle("Examen de Portugués");
        setSize(800, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        this.setLocationRelativeTo(null);

        // Panel para mostrar el número de preguntas correctas
        JPanel panelPreguntasCorrectas = new JPanel();
        JLabel labelPreguntasCorrectas = new JLabel("Preguntas correctas: 0");
        panelPreguntasCorrectas.add(labelPreguntasCorrectas);
        add(panelPreguntasCorrectas, BorderLayout.NORTH);

        // Panel para las preguntas y respuestas
        panelPreguntasRespuestas = new JPanel();
        panelPreguntasRespuestas.setLayout(new GridLayout(preguntasRespuestas.length, 2));

        // Crear etiquetas de pregunta y campos de texto para las respuestas
        for (int i = 0; i < preguntasRespuestas.length; i++) {
            JLabel labelPregunta = new JLabel(preguntasRespuestas[i][0]); // La pregunta se encuentra en la posición 0
            JTextField campoRespuesta = new JTextField();
            panelPreguntasRespuestas.add(labelPregunta);
            panelPreguntasRespuestas.add(campoRespuesta);
        }

        add(panelPreguntasRespuestas, BorderLayout.CENTER);

        // Botón para mostrar el resultado
        JButton btnMostrarResultado = new JButton("Mostrar resultado");
        btnMostrarResultado.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarResultado();
            }
        });
        add(btnMostrarResultado, BorderLayout.SOUTH);

        setVisible(true);
    }

    private void mostrarResultado() {
        int preguntasTotales = preguntasRespuestas.length;
        int respuestasCorrectas = 0;

        // Comparar las respuestas ingresadas con las respuestas correctas
        for (int i = 0; i < preguntasTotales; i++) {
            JTextField campoRespuesta = (JTextField) panelPreguntasRespuestas.getComponent(i * 2 + 1); // Obtener el campo de texto de la respuesta
            String respuestaIngresada = campoRespuesta.getText();
            String respuestaCorrecta = preguntasRespuestas[i][1]; // La respuesta correcta se encuentra en la posición 1

            if (respuestaIngresada.equalsIgnoreCase(respuestaCorrecta)) {
                respuestasCorrectas++;
            }
        }

        String mensaje;
        if (respuestasCorrectas >= preguntasTotales * 0.8) {
            mensaje = "¡Parabéns você tem um bom nível de conhecimento do idioma!";
            ModoUser user = new ModoUser();
            user.setVisible(true);
            this.setVisible(false); 
        } else if (respuestasCorrectas >= preguntasTotales * 0.5) {
            mensaje = "tem un nivel intermedio do idioma.";
            ModoUser user = new ModoUser();
            user.setVisible(true);
            this.setVisible(false); 
        } else {
            mensaje = "Tu conocimiento del idioma aún necesita mejorar.";
            ModoUser user = new ModoUser();
            user.setVisible(true);
            this.setVisible(false); 
        }

        JOptionPane.showMessageDialog(this, mensaje, "Resultado", JOptionPane.INFORMATION_MESSAGE);

        // Resto del código...
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new TestPortugues();
            }
        });
    }
}