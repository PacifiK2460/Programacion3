package FinalProyect;
import Conexion.ConexionBD;
import Login.Login;

public class FinalProyecto {
    public static void main(String args[]) {
//        arraque del sistema con la primera pestaña de arranque
        PantallaDeArranque p1 = new PantallaDeArranque();
        p1.setVisible(true);       
    }
}
