package Conexion;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;


public class ConexionBD {
    
    Connection cx;
   
   
//    Proceso de conexion a la base de datos 
    public Connection conectar(){
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                cx=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/login","root","Twice1$ua2");
                System.out.println("Conectado a la base de datos: ");
            } catch (Exception e) {
                System.out.println("No se conecto a la base de datos: ");
           }
    return cx;   
    }
//    proceso de desconectar la base de datos
    public void desconectar(){
        try {
            cx.close();
        } catch (SQLException ex) {
            Logger.getLogger(ConexionBD.class.getName()).log(Level.SEVERE, null, ex);
        }   
    }    

    public PreparedStatement PreparedStatement(String sql) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}